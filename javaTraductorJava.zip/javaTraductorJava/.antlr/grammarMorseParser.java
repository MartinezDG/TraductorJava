// Generated from /home/rusell/Ejercicios/morseCode/grammarMorse.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class grammarMorseParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		A=1, B=2, C=3, CH=4, D=5, E=6, F=7, G=8, H=9, I=10, J=11, K=12, L=13, 
		M=14, N=15, Ñ=16, O=17, P=18, Q=19, R=20, S=21, T=22, U=23, V=24, W=25, 
		X=26, Y=27, Z=28, ZERO=29, ONE=30, TWO=31, THREE=32, FOUR=33, FIVE=34, 
		SIX=35, SEVEN=36, EIGHT=37, NINE=38, DOT=39, COMMA=40, QUESTION=41, QUOTE=42, 
		SLASH=43, WS=44;
	public static final int
		RULE_morse_line = 0, RULE_letter = 1, RULE_digit = 2;
	private static String[] makeRuleNames() {
		return new String[] {
			"morse_line", "letter", "digit"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'.-'", "'-...'", "'-.-.'", "'----'", "'-..'", "'.'", "'..-.'", 
			"'--.'", "'....'", "'..'", "'.---'", "'-.-'", "'.-..'", "'--'", "'-.'", 
			"'--.--'", "'---'", "'.--.'", "'--.-'", "'.-.'", "'...'", "'-'", "'..-'", 
			"'...-'", "'.--'", "'-..-'", "'-.--'", "'--..'", "'-----'", "'.----'", 
			"'..---'", "'...--'", "'....-'", "'.....'", "'-....'", "'--...'", "'---..'", 
			"'----.'", "'.-.-.-'", "'--..--'", "'..--..'", "'.-..-.'", "'-..-.'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "A", "B", "C", "CH", "D", "E", "F", "G", "H", "I", "J", "K", "L", 
			"M", "N", "\u0000", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", 
			"Y", "Z", "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", 
			"EIGHT", "NINE", "DOT", "COMMA", "QUESTION", "QUOTE", "SLASH", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "grammarMorse.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public grammarMorseParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Morse_lineContext extends ParserRuleContext {
		public List<LetterContext> letter() {
			return getRuleContexts(LetterContext.class);
		}
		public LetterContext letter(int i) {
			return getRuleContext(LetterContext.class,i);
		}
		public List<DigitContext> digit() {
			return getRuleContexts(DigitContext.class);
		}
		public DigitContext digit(int i) {
			return getRuleContext(DigitContext.class,i);
		}
		public List<TerminalNode> WS() { return getTokens(grammarMorseParser.WS); }
		public TerminalNode WS(int i) {
			return getToken(grammarMorseParser.WS, i);
		}
		public Morse_lineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_morse_line; }
	}

	public final Morse_lineContext morse_line() throws RecognitionException {
		Morse_lineContext _localctx = new Morse_lineContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_morse_line);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(11);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 18141941858286L) != 0)) {
				{
				setState(9);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case A:
				case B:
				case C:
				case D:
				case E:
				case F:
				case G:
				case H:
				case I:
				case J:
				case K:
				case L:
				case M:
				case N:
				case Ñ:
				case O:
				case P:
				case Q:
				case R:
				case S:
				case T:
				case U:
				case V:
				case W:
				case X:
				case Y:
				case Z:
					{
					setState(6);
					letter();
					}
					break;
				case ZERO:
				case ONE:
				case TWO:
				case THREE:
				case FOUR:
				case FIVE:
				case SIX:
				case SEVEN:
				case EIGHT:
				case NINE:
					{
					setState(7);
					digit();
					}
					break;
				case WS:
					{
					setState(8);
					match(WS);
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(13);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LetterContext extends ParserRuleContext {
		public TerminalNode A() { return getToken(grammarMorseParser.A, 0); }
		public TerminalNode B() { return getToken(grammarMorseParser.B, 0); }
		public TerminalNode C() { return getToken(grammarMorseParser.C, 0); }
		public TerminalNode D() { return getToken(grammarMorseParser.D, 0); }
		public TerminalNode E() { return getToken(grammarMorseParser.E, 0); }
		public TerminalNode F() { return getToken(grammarMorseParser.F, 0); }
		public TerminalNode G() { return getToken(grammarMorseParser.G, 0); }
		public TerminalNode H() { return getToken(grammarMorseParser.H, 0); }
		public TerminalNode I() { return getToken(grammarMorseParser.I, 0); }
		public TerminalNode J() { return getToken(grammarMorseParser.J, 0); }
		public TerminalNode K() { return getToken(grammarMorseParser.K, 0); }
		public TerminalNode L() { return getToken(grammarMorseParser.L, 0); }
		public TerminalNode M() { return getToken(grammarMorseParser.M, 0); }
		public TerminalNode N() { return getToken(grammarMorseParser.N, 0); }
		public TerminalNode Ñ() { return getToken(grammarMorseParser.Ñ, 0); }
		public TerminalNode O() { return getToken(grammarMorseParser.O, 0); }
		public TerminalNode P() { return getToken(grammarMorseParser.P, 0); }
		public TerminalNode Q() { return getToken(grammarMorseParser.Q, 0); }
		public TerminalNode R() { return getToken(grammarMorseParser.R, 0); }
		public TerminalNode S() { return getToken(grammarMorseParser.S, 0); }
		public TerminalNode T() { return getToken(grammarMorseParser.T, 0); }
		public TerminalNode U() { return getToken(grammarMorseParser.U, 0); }
		public TerminalNode V() { return getToken(grammarMorseParser.V, 0); }
		public TerminalNode W() { return getToken(grammarMorseParser.W, 0); }
		public TerminalNode X() { return getToken(grammarMorseParser.X, 0); }
		public TerminalNode Y() { return getToken(grammarMorseParser.Y, 0); }
		public TerminalNode Z() { return getToken(grammarMorseParser.Z, 0); }
		public LetterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_letter; }
	}

	public final LetterContext letter() throws RecognitionException {
		LetterContext _localctx = new LetterContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_letter);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(14);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 536870894L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DigitContext extends ParserRuleContext {
		public TerminalNode ZERO() { return getToken(grammarMorseParser.ZERO, 0); }
		public TerminalNode ONE() { return getToken(grammarMorseParser.ONE, 0); }
		public TerminalNode TWO() { return getToken(grammarMorseParser.TWO, 0); }
		public TerminalNode THREE() { return getToken(grammarMorseParser.THREE, 0); }
		public TerminalNode FOUR() { return getToken(grammarMorseParser.FOUR, 0); }
		public TerminalNode FIVE() { return getToken(grammarMorseParser.FIVE, 0); }
		public TerminalNode SIX() { return getToken(grammarMorseParser.SIX, 0); }
		public TerminalNode SEVEN() { return getToken(grammarMorseParser.SEVEN, 0); }
		public TerminalNode EIGHT() { return getToken(grammarMorseParser.EIGHT, 0); }
		public TerminalNode NINE() { return getToken(grammarMorseParser.NINE, 0); }
		public DigitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_digit; }
	}

	public final DigitContext digit() throws RecognitionException {
		DigitContext _localctx = new DigitContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_digit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(16);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 549218942976L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001,\u0013\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0001\u0000\u0001\u0000\u0001\u0000\u0005\u0000\n\b"+
		"\u0000\n\u0000\f\u0000\r\t\u0000\u0001\u0001\u0001\u0001\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0000\u0000\u0003\u0000\u0002\u0004\u0000\u0002\u0002"+
		"\u0000\u0001\u0003\u0005\u001c\u0001\u0000\u001d&\u0012\u0000\u000b\u0001"+
		"\u0000\u0000\u0000\u0002\u000e\u0001\u0000\u0000\u0000\u0004\u0010\u0001"+
		"\u0000\u0000\u0000\u0006\n\u0003\u0002\u0001\u0000\u0007\n\u0003\u0004"+
		"\u0002\u0000\b\n\u0005,\u0000\u0000\t\u0006\u0001\u0000\u0000\u0000\t"+
		"\u0007\u0001\u0000\u0000\u0000\t\b\u0001\u0000\u0000\u0000\n\r\u0001\u0000"+
		"\u0000\u0000\u000b\t\u0001\u0000\u0000\u0000\u000b\f\u0001\u0000\u0000"+
		"\u0000\f\u0001\u0001\u0000\u0000\u0000\r\u000b\u0001\u0000\u0000\u0000"+
		"\u000e\u000f\u0007\u0000\u0000\u0000\u000f\u0003\u0001\u0000\u0000\u0000"+
		"\u0010\u0011\u0007\u0001\u0000\u0000\u0011\u0005\u0001\u0000\u0000\u0000"+
		"\u0002\t\u000b";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}