public class TraductorPythonAJava {
    public static void main(String[] args) {
    public static int multiplica(int a, int b) {
        result = a*b-a;
        return result;
        System.out.println(multiplica(5,6));
    }
    }
}